## Times for Simple zkApp

| Name | time passed in s |
|---|---|
|Simple zkApp test flow|113.46|

In total, it took 113.46 seconds to run the entire benchmark


## Times for Simple zkApp

| Name | time passed in s |
|---|---|
|Simple zkApp test flow|113.01|

In total, it took 113.01 seconds to run the entire benchmark


## Times for Simple zkApp

| Name | time passed in s |
|---|---|
|Simple zkApp test flow|111.41|

In total, it took 111.41 seconds to run the entire benchmark


## Times for Simple zkApp

| Name | time passed in s |
|---|---|
|Simple zkApp test flow|83.86|

In total, it took 83.86 seconds to run the entire benchmark


## Times for Simple zkApp

| Name | time passed in s |
|---|---|
|Simple zkApp test flow|36.95|

In total, it took 36.95 seconds to run the entire benchmark


## Times for Simple zkApp

| Name | time passed in s |
|---|---|
|Simple zkApp test flow|101.6|

In total, it took 101.6 seconds to run the entire benchmark


## Times for Simple zkApp

| Name | time passed in s |
|---|---|
|Simple zkApp test flow|26.09|

In total, it took 26.09 seconds to run the entire benchmark


## Times for Simple zkApp

| Name | time passed in s |
|---|---|
|Simple zkApp test flow|47.97|

In total, it took 47.97 seconds to run the entire benchmark


## Times for Crowd-Funding zkApp

| Name | time passed in s |
|---|---|
|Crowd-Funding zkApp test flow|11.76|

In total, it took 11.76 seconds to run the entire benchmark


## Times for Crowd-Funding zkApp

| Name | time passed in s |
|---|---|
|Crowd-Funding zkApp test flow|11.51|

In total, it took 11.51 seconds to run the entire benchmark


## Times for Crowd-Funding zkApp

| Name | time passed in s |
|---|---|
|Crowd-Funding zkApp test flow|10.91|

In total, it took 10.91 seconds to run the entire benchmark


## Times for Crowd-Funding zkApp

| Name | time passed in s |
|---|---|
|Crowd-Funding zkApp test flow|112.5|

In total, it took 112.5 seconds to run the entire benchmark


## Times for Crowd-Funding zkApp

| Name | time passed in s |
|---|---|
|Crowd-Funding zkApp test flow|11.15|

In total, it took 11.15 seconds to run the entire benchmark


## Times for Crowd-Funding zkApp

| Name | time passed in s |
|---|---|
|Crowd-Funding zkApp test flow|13.57|

In total, it took 13.57 seconds to run the entire benchmark


## Times for Crowd-Funding zkApp

| Name | time passed in s |
|---|---|
|Crowd-Funding zkApp test flow|77.06|

In total, it took 77.06 seconds to run the entire benchmark


## Times for Crowd-Funding zkApp

| Name | time passed in s |
|---|---|
|Crowd-Funding zkApp test flow|11.84|

In total, it took 11.84 seconds to run the entire benchmark


## Times for Crowd-Funding zkApp

| Name | time passed in s |
|---|---|
|Crowd-Funding zkApp test flow|13.27|

In total, it took 13.27 seconds to run the entire benchmark


## Times for Crowd-Funding zkApp

| Name | time passed in s |
|---|---|
|Crowd-Funding zkApp test flow|11.39|

In total, it took 11.39 seconds to run the entire benchmark


## Times for Crowd-Funding zkApp

| Name | time passed in s |
|---|---|
|Crowd-Funding zkApp test flow|12.08|

In total, it took 12.08 seconds to run the entire benchmark


## Times for Crowd-Funding zkApp

| Name | time passed in s |
|---|---|
|Crowd-Funding zkApp test flow|12.17|

In total, it took 12.17 seconds to run the entire benchmark


## Times for Crowd-Funding zkApp

| Name | time passed in s |
|---|---|
|Crowd-Funding zkApp test flow|9.41|

In total, it took 9.41 seconds to run the entire benchmark


## Times for Crowd-Funding zkApp

| Name | time passed in s |
|---|---|
|Crowd-Funding zkApp test flow|11.33|

In total, it took 11.33 seconds to run the entire benchmark


## Times for Crowd-Funding zkApp

| Name | time passed in s |
|---|---|
|Crowd-Funding zkApp test flow|11.25|

In total, it took 11.25 seconds to run the entire benchmark


## Times for Crowd-Funding zkApp

| Name | time passed in s |
|---|---|
|Crowd-Funding zkApp test flow|12.09|

In total, it took 12.09 seconds to run the entire benchmark


## Times for Crowd-Funding zkApp

| Name | time passed in s |
|---|---|
|Crowd-Funding zkApp test flow|11.52|

In total, it took 11.52 seconds to run the entire benchmark


## Times for Crowd-Funding zkApp

| Name | time passed in s |
|---|---|
|Crowd-Funding zkApp test flow|242.51|

In total, it took 242.51 seconds to run the entire benchmark


## Times for Crowd-Funding zkApp

| Name | time passed in s |
|---|---|
|Crowd-Funding zkApp test flow|287.41|

In total, it took 287.41 seconds to run the entire benchmark


## Times for Crowd-Funding zkApp

| Name | time passed in s |
|---|---|
|Crowd-Funding zkApp test flow|130.82|

In total, it took 130.82 seconds to run the entire benchmark


## Times for Crowd-Funding zkApp

| Name | time passed in s |
|---|---|
|Crowd-Funding zkApp test flow|132.81|

In total, it took 132.81 seconds to run the entire benchmark


## Times for Crowd-Funding zkApp

| Name | time passed in s |
|---|---|
|Crowd-Funding zkApp test flow|134.34|

In total, it took 134.34 seconds to run the entire benchmark


## Times for Crowd-Funding zkApp

| Name | time passed in s |
|---|---|
|Crowd-Funding zkApp test flow|295.07|

In total, it took 295.07 seconds to run the entire benchmark


## Times for Crowd-Funding zkApp

| Name | time passed in s |
|---|---|
|Crowd-Funding zkApp test flow|166.72|

In total, it took 166.72 seconds to run the entire benchmark


## Times for Crowd-Funding zkApp

| Name | time passed in s |
|---|---|
|Crowd-Funding zkApp test flow|151.38|

In total, it took 151.38 seconds to run the entire benchmark


## Times for Crowd-Funding zkApp

| Name | time passed in s |
|---|---|
|Crowd-Funding zkApp test flow|176.99|

In total, it took 176.99 seconds to run the entire benchmark


