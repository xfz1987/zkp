import { UInt64 } from 'o1js';

export function formatMina(amount: UInt64): string {
  return (Number(amount) / 1e9).toString();
}

export async function getCurrentBlockHeight(): Promise<number> {
  try {
    const response = await fetch(
      'https://api.minascan.io/node/devnet/v1/graphql',
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          query: `
                  query {
                      bestChain(maxLength: 1) {
                          protocolState {
                              consensusState {
                                  blockHeight
                              }
                          }
                      }
                  }
              `,
        }),
      }
    );
    const data = await response.json();
    if (
      !data.data?.bestChain?.[0]?.protocolState?.consensusState?.blockHeight
    ) {
      throw new Error('无法获取区块高度');
    }
    return parseInt(
      data.data.bestChain[0].protocolState.consensusState.blockHeight
    );
  } catch (error) {
    console.error('获取区块高度失败:', error);
    throw error;
  }
}
