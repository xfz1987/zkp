// test1
export const test1 = 'EKFC653ZrhqsaDxbnnov5AhU4hrEwWavAuqaTpAvrdBEHUVyyeDg';

// test2
export const test2 = 'EKEQtLsKQcTMMzmXZnM6ZEaFoKWw5NebpR72zoBbsUEMNcoixVhp';
