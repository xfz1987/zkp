This folder doesn't contain stand-alone examples, but utilities used in our examples.
